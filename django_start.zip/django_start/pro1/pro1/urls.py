
from django.contrib import admin
from django.urls import path

from django.shortcuts import HttpResponse,render


def myfun(request):

    a="""<h1 style='color:red'>Hello django</h1>
    
    sdldfkjsdfl4
    sdfdsf;lsdf
    sdfdsfds
    sdfsdf
    
    """


    return HttpResponse(a)

def index(req):
    a='Raj Kushwaha'
    b=["hello ",500,900, "fkjsdhfkjs"]
    myd ={'name':a,'vname':b}
    return render(req,'index.html',myd)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('hh/', myfun),
    path('i/', index),

]
