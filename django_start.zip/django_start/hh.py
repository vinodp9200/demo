

# a="Raj Kushwaha"
# print(a[::-1])
# s=""
# for i in a:
#    s = i + s
# print(s)
#
#
# a=5,
# print(type(a))

# s={5,8,10,8,8}
# # for i in s:
# #     print(i)

v={0,}
print(type(v))